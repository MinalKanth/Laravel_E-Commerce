<?php 

// define pase url for the project 
define("BURL","http://localhost:800/");


/**
 * database configuration 
 */

define("DB_HOST","localhost");
define("DB_USER","root");
define("DB_PASS","");
define("DB_NAME","learn_crud_mvc");