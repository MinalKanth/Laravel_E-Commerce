<?php
namespace App;
use Illuminate\Database\Eloquent\Model;
class Data extends Model {
	protected $table = 'bootgrid_data';
	public $timestamps = false;
}
