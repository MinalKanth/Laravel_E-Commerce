# dataTables custom row buttons

A Pen created on CodePen.io. Original URL: [https://codepen.io/RedJokingInn/pen/zZyRmR](https://codepen.io/RedJokingInn/pen/zZyRmR).

Example on how to integrate custom buttons in a datatable and add events to them.