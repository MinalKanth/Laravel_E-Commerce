
<h1>Customer List</h1>
<table>
  <thead>
    <tr>
      <th>ID</th>
      <th>Name</th>
      <th>Email</th>
      <th>Phone</th>
    </tr>
  </thead>
  <tbody>
   
      <tr>
        <td>{{ $value['url'] }}</td>
        <td>{{ $value['category'] }}</td>
        <td>{{ $value['country'] }}</td>
        <td>{{ $value['county'] }}</td>
      </tr>
  </tbody>
</table>