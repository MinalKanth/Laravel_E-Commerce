Author: Yogesh singh
Author URL: https://makitweb.com/
Author Email: makitweb@gmail.com
Tutorial Link: https://makitweb.com/delete-multiple-selected-records-in-datatables-php/

Instructions - 
1. Import employee.sql table in your MySQL database.
2. Update config.php file.

